/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pointer.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: andrii <andrii@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/03 09:12:34 by andrii            #+#    #+#             */
/*   Updated: 2024/11/05 20:04:06 by andrii           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "printf.h"

int	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
    return (i);
}

int ft_putnbr_hex(uintptr_t num)
{
    char hex_digs[] = "0123456789abcdef";
    int i;

    i = 0;
    if (num >= 16)
    {
        i += ft_putnbr_hex(num / 16);
    }
    i += ft_print_char(hex_digs[num % 16]);
    return (i);
}

int print_pointer(void *ptr)
{
    int i;

    i = 0;
    if (ptr == 0)
    {
        i += ft_putstr("(null)");
    }
    else
    {
        write(1, "0x", 2);
        i += ft_putnbr_hex((uintptr_t)ptr);
    }
    return (i);
}