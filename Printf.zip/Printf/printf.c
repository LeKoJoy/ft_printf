/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   printf.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anhoncha<andrii@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/23 12:58:05 by anhoncha           #+#    #+#             */
/*   Updated: 2024/10/23 12:58:13 by anhoncha          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "printf.h"

int	flagprocess(va_list args, const char input)
{
	int	i;

	i = 0;
	if (input == 'c')
		i += ft_print_char(va_arg(args, int));
	else if (input == 's')
		i += ft_print_str(va_arg(args, char *));
	else if (input == 'd' || input == 'i')
		i += ft_printint(va_arg(args, int));
	if (input == 'x' || input == 'X')
		i += print_hex(va_arg(args, unsigned int), input);
	if (input == 'u')
		i += print_uint(va_arg(args, unsigned int));
	else if (input == '%')
		i += ft_printpercent();
	else if (input == 'p')
		i += print_pointer(va_arg(args, void *));
	return (i);
}

int	ft_printf(const char *input, ...)
{
	va_list			args;
	unsigned int	i;
	unsigned int	len;

	i = 0;
	len = 0;
	va_start(args, input);
	while (input[i])
	{
		if (input[i] == '%')
		{
			len += flagprocess(args, input[i + 1]);
			i++;
		}
		else
			len += ft_print_char(input[i]);
		i++;
	}
	va_end(args);
	return (len);
}

int main(void)
{
	int		i = 5;
	char *s = "s";
	ft_printf("ft_print: integer: %p, %d", s, i);
	write(1, "\n", 2);
	printf("printf: integer: %p, %d", s, i);
	return (0);
}
