#ifndef PRINTF_H
#define PRINTF_H

# include "./libft/libft.h"
# include <stdlib.h>
# include <unistd.h>
# include <stdarg.h>
# include <stdio.h>
# include <stddef.h>
# include <stdint.h>
# include <limits.h>

int	ft_printf(const char *input, ...);
int	ft_print_char(int c);
int ft_print_str(char *str);
int	ft_printpercent(void);
int	ft_printint(int a);
int print_pointer(void *ptr);
int print_uint(unsigned int n);
int print_hex(unsigned int n, char formatter);

#endif