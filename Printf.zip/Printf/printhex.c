/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   printhex.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: andrii <andrii@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/05 20:28:41 by andrii            #+#    #+#             */
/*   Updated: 2024/11/05 20:42:27 by andrii           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "printf.h"

int ft_putnbr_hexx(uintptr_t num)
{
    char hex_digs[] = "0123456789abcdef";
    int i;

    i = 0;
    if (num >= 16)
    {
        i += ft_putnbr_hexx(num / 16);
    }
    i += ft_print_char(hex_digs[num % 16]);
    return (i);
}

int ft_putnbr_hexX(uintptr_t num)
{
    char hex_digs[] = "0123456789ABCDEF";
    int i;

    i = 0;
    if (num >= 16)
    {
        i += ft_putnbr_hexX(num / 16);
    }
    i += ft_print_char(hex_digs[num % 16]);
    return (i);
}

int print_hex(unsigned int n, char formatter)
{
    int i;

    i = 0;
    if (n == 0)
    {
        i += ft_print_str("0");
    }
    else
    {
        if (formatter == 'x')
            i += ft_putnbr_hexx((uintptr_t)n);
        else if (formatter == 'X')
            i += ft_putnbr_hexX((uintptr_t)n);
    }
    return (i);
}