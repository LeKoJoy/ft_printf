/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   processes.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: andrii <andrii@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/04 19:14:04 by andrii            #+#    #+#             */
/*   Updated: 2024/11/05 20:28:01 by andrii           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "printf.h"

int	ft_print_char(int c)
{
	write(1, &c, 1);
	return (1);
}

int ft_print_str(char *str)
{
	int	i;

	i = 0;
	if (str == NULL)
	{
		ft_print_str("(null)");
		return (6);
	}
	while (str[i])
	{
		write (1, &str[i], 1);
		i++;
	}
	return (i);
}

int	ft_printpercent(void)
{
	write(1, "%", 1);
	return (1);
}

int	ft_printint(int a)
{
	char	*nb;
	int		i;

	i = 0;
	nb = ft_itoa(a);
	i = ft_print_str(nb);
	free(nb);
	return (i);
}
int print_uint(unsigned int n)
{
	int	i;

	i = 0;
	if (n == 0)
		return (ft_print_char('0'));
	if (n>9)
	{
		i += print_uint(n / 10);
		n = n % 10;
	}
	i += ft_print_char((n % 10) + 48);
	return (i);
}